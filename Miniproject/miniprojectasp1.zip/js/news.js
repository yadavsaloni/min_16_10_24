﻿function deletenews(id)
{
    alert(confirm("are you deleted data? this  data will be not recover"))
    {
        window.location.href = "News.aspx?id=" + id;
    }
}

